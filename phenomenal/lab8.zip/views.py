from django.shortcuts import render
from django.http import HttpResponse
from .models import Category, Product, Client, Order
from django.shortcuts import get_object_or_404
from .forms import OrderForm
from .forms import InterestForm


# Create your views here.

def index(request):
    cat_list = Category.objects.all().order_by('id')[:10]
    return render(request, 'myapp/index.html',{'cat_list':cat_list})


def about(request):
    return render(request, 'myapp/about.html')

def products(request):
 prodlist = Product.objects.all().order_by('id')[:10]
 return render(request, 'myapp/products.html', {'prodlist': prodlist})


def detail(request, cat_no):
    cat_number = cat_no
    cat_list = Category.objects.all()
    product_list = Product.objects.all()
    a = 0
    n = []
    for c in cat_list:
        if cat_number == c.id:
            m = c.warehouse
            print(m)
            a = 1


            for p in product_list:
                print(p.name)
                if m == p.category.name:
                    print("true")


    if a == 0:
        return get_object_or_404(Category, id=cat_no)

    return render(request, 'myapp/detail.html', {'m': m})


def place_order(request):
    msg = ''
    prodlist = Product.objects.all()
    if request.method == 'POST':
        form = OrderForm(request.POST)
        print("saved1")
        if form.is_valid():
            order = form.save()
            print("saved")
            if order.num_units <= order.product.stock:
                order.save()
                order.product.stock = order.product.stock - order.num_units
                print("stock",order.product.stock)
                msg = 'Your order has been placed successfully.'
            else:
                msg = 'We do not have sufficient stock to fill your order.'
            return render(request, 'myapp/order_response.html', {'msg': msg})

    else:
        form = OrderForm()
        print("not saved")
    return render(request, 'myapp/placeorder.html', {'form': form, 'msg': msg,
                                                     'prodlist': prodlist})

def response(request):
    return render(request, "myapp/order_response.html")

def productdetail(request, prod_id):
    form = InterestForm()
    prod_info = Product.objects.filter(category=prod_id)
    return render(request, 'myapp/productdetail.html', {'prod_info':prod_info, 'form': InterestForm })